import React, { useState, useRef } from 'react';
import { Upload, PenTool, Camera as CameraIcon, BrainCircuit, Trash2, Send } from 'lucide-react';
import DrawingCanvas from './components/DrawingCanvas';
import CameraCapture from './components/CameraCapture';
import ResultsPanel from './components/ResultsPanel';
import { analyzeHandwriting } from './services/geminiService';
import { RecognitionResult, InputMode, CanvasRef } from './types';

const App: React.FC = () => {
  const [inputMode, setInputMode] = useState<InputMode>(InputMode.DRAW);
  const [result, setResult] = useState<RecognitionResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const canvasRef = useRef<CanvasRef>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  const handleAnalyze = async (imageData: string | null) => {
    if (!imageData) return;
    
    setIsLoading(true);
    setResult(null);
    
    try {
      const data = await analyzeHandwriting(imageData);
      setResult(data);
    } catch (error) {
      console.error("Analysis failed", error);
    } finally {
      setIsLoading(false);
    }
  };

  const onCanvasSubmit = () => {
    const dataUrl = canvasRef.current?.getDataUrl();
    handleAnalyze(dataUrl || null);
  };

  const onClearCanvas = () => {
    canvasRef.current?.clear();
    setResult(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setUploadedImage(result);
        handleAnalyze(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCameraCapture = (imageData: string) => {
    handleAnalyze(imageData);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-primary-500/30">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-primary-500 p-2 rounded-lg">
              <BrainCircuit className="text-slate-900 w-6 h-6" />
            </div>
            <div>
              <h1 className="font-bold text-white text-lg tracking-tight">BhashaLLM</h1>
              <div className="text-xs text-slate-400 font-mono">v2.5-FLASH // BHASHA ENGINE</div>
            </div>
          </div>
          <a 
            href="#" 
            className="text-xs text-slate-500 hover:text-primary-400 transition-colors font-mono hidden sm:block"
          >
            SYSTEM_STATUS::ONLINE
          </a>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Input Area */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Tabs */}
          <div className="bg-slate-900 p-1 rounded-xl flex shadow-inner border border-slate-800">
            {[
              { id: InputMode.DRAW, icon: PenTool, label: 'Sketch' },
              { id: InputMode.UPLOAD, icon: Upload, label: 'Upload' },
              { id: InputMode.CAMERA, icon: CameraIcon, label: 'Camera' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  setInputMode(tab.id);
                  setResult(null);
                  setUploadedImage(null);
                }}
                className={`flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium rounded-lg transition-all ${
                  inputMode === tab.id 
                    ? 'bg-primary-500 text-slate-950 shadow-lg' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <tab.icon size={18} />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Content Area */}
          <div className="min-h-[400px]">
            {inputMode === InputMode.DRAW && (
              <div className="space-y-4">
                <DrawingCanvas ref={canvasRef} width={window.innerWidth < 600 ? window.innerWidth - 40 : 600} height={400} />
                <div className="flex gap-3">
                  <button 
                    onClick={onClearCanvas}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium transition-colors border border-slate-700"
                  >
                    <Trash2 size={18} />
                    Clear Board
                  </button>
                  <button 
                    onClick={onCanvasSubmit}
                    disabled={isLoading}
                    className="flex-[2] flex items-center justify-center gap-2 px-4 py-3 bg-white text-slate-900 hover:bg-primary-50 rounded-xl font-bold transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_0_15px_rgba(217,119,6,0.3)] hover:shadow-[0_0_25px_rgba(217,119,6,0.5)]"
                  >
                    {isLoading ? (
                      <span className="flex items-center gap-2">Processing...</span>
                    ) : (
                      <>
                        <Send size={18} />
                        Analyze Sketch
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {inputMode === InputMode.UPLOAD && (
              <div className="h-[400px] border-2 border-dashed border-slate-700 rounded-xl bg-slate-900/50 flex flex-col items-center justify-center relative overflow-hidden group hover:border-primary-500/50 transition-colors">
                {uploadedImage ? (
                  <>
                    <img src={uploadedImage} alt="Uploaded" className="max-w-full max-h-full object-contain p-4" />
                    <button 
                      onClick={() => { setUploadedImage(null); fileInputRef.current!.value = ''; }}
                      className="absolute top-4 right-4 bg-slate-900/80 text-white p-2 rounded-full hover:bg-red-500/80 transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </>
                ) : (
                  <div className="text-center p-8">
                    <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                      <Upload className="text-primary-400" size={32} />
                    </div>
                    <h3 className="text-lg font-medium text-white mb-2">Drop your image here</h3>
                    <p className="text-slate-400 text-sm mb-6 max-w-xs mx-auto">Support for JPG, PNG. Optimized for handwritten notes and digits.</p>
                    <input 
                      type="file" 
                      ref={fileInputRef}
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      className="px-6 py-2 bg-primary-500 hover:bg-primary-600 text-slate-950 rounded-lg font-medium transition-colors"
                    >
                      Browse Files
                    </button>
                  </div>
                )}
              </div>
            )}

            {inputMode === InputMode.CAMERA && (
              <div className="h-[500px]">
                <CameraCapture onCapture={handleCameraCapture} />
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Results */}
        <div className="lg:col-span-5">
           <div className="bg-slate-900/50 rounded-2xl border border-slate-800 p-1 h-full min-h-[500px]">
              <div className="h-full bg-slate-950/50 rounded-xl p-4">
                <ResultsPanel result={result} isLoading={isLoading} />
              </div>
           </div>
        </div>

      </main>

      <footer className="max-w-7xl mx-auto px-4 py-6 border-t border-slate-800 mt-8">
        <div className="flex justify-between items-center text-xs text-slate-500 font-mono">
          <p>POWERED BY GOOGLE GEMINI API</p>
          <p>BHASHALLM SYSTEM v1.0.4</p>
        </div>
      </footer>
    </div>
  );
};

export default App;