import React, { useRef, useState, useEffect, useImperativeHandle, forwardRef } from 'react';
import { CanvasRef } from '../types';

interface DrawingCanvasProps {
  width: number;
  height: number;
}

const DrawingCanvas = forwardRef<CanvasRef, DrawingCanvasProps>(({ width, height }, ref) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const contextRef = useRef<CanvasRenderingContext2D | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Handle high DPI displays
    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.scale(dpr, dpr);
      ctx.lineCap = 'round';
      // Use the primary skin/bronze color for drawing
      ctx.strokeStyle = '#e8b488'; 
      ctx.lineWidth = 4;
      ctx.fillStyle = '#1c1917'; // Match slate-900 (Stone) background
      ctx.fillRect(0, 0, width, height); // Fill background so it's not transparent
      contextRef.current = ctx;
    }
  }, [width, height]);

  useImperativeHandle(ref, () => ({
    clear: () => {
      const canvas = canvasRef.current;
      const ctx = contextRef.current;
      if (canvas && ctx) {
        ctx.fillStyle = '#1c1917'; // Match slate-900 (Stone)
        ctx.fillRect(0, 0, width, height);
      }
    },
    getDataUrl: () => {
      return canvasRef.current?.toDataURL('image/png') || null;
    }
  }));

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    const { offsetX, offsetY } = getCoordinates(e);
    contextRef.current?.beginPath();
    contextRef.current?.moveTo(offsetX, offsetY);
    setIsDrawing(true);
  };

  const finishDrawing = () => {
    contextRef.current?.closePath();
    setIsDrawing(false);
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing) return;
    const { offsetX, offsetY } = getCoordinates(e);
    contextRef.current?.lineTo(offsetX, offsetY);
    contextRef.current?.stroke();
  };

  const getCoordinates = (e: React.MouseEvent | React.TouchEvent) => {
    if (!canvasRef.current) return { offsetX: 0, offsetY: 0 };
    
    // Check if it's a touch event
    if ('touches' in e) {
      const rect = canvasRef.current.getBoundingClientRect();
      const touch = e.touches[0];
      return {
        offsetX: touch.clientX - rect.left,
        offsetY: touch.clientY - rect.top
      };
    } else {
      // Mouse event
      return {
        offsetX: (e as React.MouseEvent).nativeEvent.offsetX,
        offsetY: (e as React.MouseEvent).nativeEvent.offsetY
      };
    }
  };

  return (
    <div className="relative border-2 border-slate-700 rounded-xl overflow-hidden shadow-2xl bg-slate-900 cursor-crosshair">
      <canvas
        ref={canvasRef}
        onMouseDown={startDrawing}
        onMouseUp={finishDrawing}
        onMouseMove={draw}
        onMouseLeave={finishDrawing}
        onTouchStart={startDrawing}
        onTouchEnd={finishDrawing}
        onTouchMove={draw}
        className="touch-none"
      />
      <div className="absolute top-4 right-4 text-xs text-slate-500 font-mono pointer-events-none select-none">
        CANVAS_MODE::ACTIVE
      </div>
    </div>
  );
});

DrawingCanvas.displayName = 'DrawingCanvas';
export default DrawingCanvas;