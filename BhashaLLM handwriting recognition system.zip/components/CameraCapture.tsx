import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Camera, RefreshCw, XCircle } from 'lucide-react';

interface CameraCaptureProps {
  onCapture: (imageData: string) => void;
}

const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);

  const startCamera = useCallback(async () => {
    try {
      setError(null);
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } } 
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      console.error("Camera access error:", err);
      setError("Unable to access camera. Please check permissions.");
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
      setIsReady(false);
    }
  }, [stream]);

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      // Set canvas dimensions to match video
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = canvas.toDataURL('image/png');
        onCapture(imageData);
      }
    }
  };

  const handleVideoLoaded = () => {
    setIsReady(true);
  };

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-64 bg-slate-900 rounded-xl border-2 border-red-900/50 text-red-400 gap-4 p-6">
        <XCircle size={48} />
        <p className="text-center">{error}</p>
        <button 
          onClick={startCamera}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-sm font-medium transition-colors"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="relative bg-slate-900 rounded-xl overflow-hidden border-2 border-slate-700 shadow-2xl">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        onLoadedMetadata={handleVideoLoaded}
        className="w-full h-full object-cover min-h-[300px] max-h-[500px]"
      />
      <canvas ref={canvasRef} className="hidden" />
      
      <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-4 z-10">
        {!isReady && (
           <div className="text-slate-400 text-sm animate-pulse bg-slate-900/80 px-4 py-2 rounded-full">Initializing sensors...</div>
        )}
        
        {isReady && (
          <>
            <button
              onClick={handleCapture}
              className="group relative flex items-center justify-center w-16 h-16 rounded-full bg-white hover:scale-105 transition-all focus:outline-none focus:ring-4 focus:ring-primary-500/50"
              aria-label="Capture Photo"
            >
              <div className="w-14 h-14 rounded-full border-2 border-slate-900 group-hover:border-primary-600 transition-colors"></div>
              <Camera className="absolute w-6 h-6 text-slate-900" />
            </button>
            
            <button
              onClick={() => { stopCamera(); setTimeout(startCamera, 100); }}
              className="absolute right-6 top-1/2 -translate-y-1/2 p-3 bg-slate-900/70 hover:bg-slate-800 text-white rounded-full backdrop-blur-sm transition-colors"
              title="Restart Camera"
            >
              <RefreshCw size={20} />
            </button>
          </>
        )}
      </div>
      
      {/* HUD Overlay effects */}
      <div className="absolute top-4 left-4 border-t-2 border-l-2 border-primary-500 w-8 h-8 opacity-50"></div>
      <div className="absolute top-4 right-4 border-t-2 border-r-2 border-primary-500 w-8 h-8 opacity-50"></div>
      <div className="absolute bottom-4 left-4 border-b-2 border-l-2 border-primary-500 w-8 h-8 opacity-50"></div>
      <div className="absolute bottom-4 right-4 border-b-2 border-r-2 border-primary-500 w-8 h-8 opacity-50"></div>
    </div>
  );
};

export default CameraCapture;