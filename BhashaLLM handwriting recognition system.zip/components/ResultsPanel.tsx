import React from 'react';
import { RecognitionResult } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { CheckCircle, AlertCircle, Clock, Activity } from 'lucide-react';

interface ResultsPanelProps {
  result: RecognitionResult | null;
  isLoading: boolean;
}

const ResultsPanel: React.FC<ResultsPanelProps> = ({ result, isLoading }) => {
  if (isLoading) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-12 space-y-6 text-slate-400">
        <div className="relative">
          <div className="w-16 h-16 border-4 border-primary-500/30 border-t-primary-500 rounded-full animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-8 h-8 bg-primary-500/20 rounded-full animate-pulse"></div>
          </div>
        </div>
        <div className="text-center space-y-2">
          <h3 className="text-lg font-mono text-white">Processing Input</h3>
          <p className="text-sm">Running neural inference...</p>
        </div>
      </div>
    );
  }

  if (!result) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-12 text-slate-500 border-2 border-dashed border-slate-800 rounded-xl">
        <Activity size={48} className="mb-4 opacity-50" />
        <p className="text-center font-medium">No analysis data available</p>
        <p className="text-sm text-center opacity-70">Submit an image to see results</p>
      </div>
    );
  }

  const confidenceColor = result.confidence > 80 ? '#22c55e' : result.confidence > 50 ? '#eab308' : '#ef4444';

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Primary Result Card */}
      <div className="bg-slate-800 rounded-xl p-6 shadow-lg border border-slate-700 relative overflow-hidden group">
        <div className="absolute top-0 left-0 w-1 h-full" style={{ backgroundColor: confidenceColor }}></div>
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-slate-400 text-xs font-mono uppercase tracking-wider mb-1">Recognized Text</h3>
            <div className="text-4xl font-bold text-white font-mono break-all">{result.recognizedText}</div>
          </div>
          <div className="text-right">
            <div className="inline-flex items-center gap-2 bg-slate-900/50 px-3 py-1 rounded-full border border-slate-700">
              {result.confidence > 80 ? <CheckCircle size={14} className="text-green-500" /> : <AlertCircle size={14} className="text-yellow-500" />}
              <span className="text-sm font-mono font-bold" style={{ color: confidenceColor }}>
                {result.confidence.toFixed(1)}%
              </span>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mt-4 pt-4 border-t border-slate-700/50">
          <div>
            <span className="text-slate-500 text-xs block mb-1">Inference Time</span>
            <div className="flex items-center gap-2 text-slate-300 font-mono text-sm">
              <Clock size={14} />
              {result.processingTimeMs}ms
            </div>
          </div>
          <div>
             <span className="text-slate-500 text-xs block mb-1">Model</span>
             <div className="text-primary-400 font-mono text-sm">Gemini 2.5 Flash</div>
          </div>
        </div>
      </div>

      {/* Analysis Section */}
      <div className="bg-slate-800 rounded-xl p-6 shadow-lg border border-slate-700">
        <h3 className="text-slate-400 text-xs font-mono uppercase tracking-wider mb-3">Structural Analysis</h3>
        <p className="text-slate-300 text-sm leading-relaxed">
          {result.analysis}
        </p>
      </div>

      {/* Probability Chart */}
      <div className="bg-slate-800 rounded-xl p-6 shadow-lg border border-slate-700">
        <h3 className="text-slate-400 text-xs font-mono uppercase tracking-wider mb-4">Candidate Probabilities</h3>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={result.candidates} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <XAxis type="number" hide domain={[0, 1]} />
              <YAxis 
                type="category" 
                dataKey="label" 
                width={30} 
                tick={{ fill: '#a8a29e', fontSize: 14, fontFamily: 'monospace' }} 
                axisLine={false}
                tickLine={false}
              />
              <Tooltip 
                cursor={{fill: '#44403c', opacity: 0.4}}
                contentStyle={{ backgroundColor: '#0c0a09', borderColor: '#44403c', color: '#e7e5e4' }}
                itemStyle={{ color: '#e8b488' }}
                formatter={(value: number) => [`${(value * 100).toFixed(1)}%`, 'Probability']}
              />
              <Bar dataKey="probability" radius={[0, 4, 4, 0]} barSize={20}>
                {result.candidates.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={index === 0 ? '#d68c45' : '#57534e'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default ResultsPanel;