export interface PredictionCandidate {
  label: string;
  probability: number;
}

export interface RecognitionResult {
  recognizedText: string;
  confidence: number;
  analysis: string;
  candidates: PredictionCandidate[];
  processingTimeMs: number;
}

export enum InputMode {
  DRAW = 'DRAW',
  UPLOAD = 'UPLOAD',
  CAMERA = 'CAMERA'
}

export interface CanvasRef {
  clear: () => void;
  getDataUrl: () => string | null;
}