import { GoogleGenAI, Type, Schema } from "@google/genai";
import { PredictionCandidate, RecognitionResult } from "../types";

// Define the schema for structured output from Gemini
const recognitionSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    recognizedText: {
      type: Type.STRING,
      description: "The exact text content identified in the image.",
    },
    confidence: {
      type: Type.NUMBER,
      description: "A confidence score between 0 and 100 indicating certainty.",
    },
    analysis: {
      type: Type.STRING,
      description: "A brief technical analysis of the handwriting style (e.g., cursive, block, messy, stroke width).",
    },
    candidates: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          label: { type: Type.STRING },
          probability: { type: Type.NUMBER },
        },
      },
      description: "A list of top 3-5 possible interpretations of the text with their probabilities (0-1).",
    },
  },
  required: ["recognizedText", "confidence", "analysis", "candidates"],
};

export const analyzeHandwriting = async (base64Image: string): Promise<RecognitionResult> => {
  const startTime = performance.now();
  
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      throw new Error("API Key not found");
    }

    const ai = new GoogleGenAI({ apiKey });

    // Clean base64 string if it contains metadata header
    const cleanBase64 = base64Image.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        responseMimeType: "application/json",
        responseSchema: recognitionSchema,
        systemInstruction: "You are an advanced Optical Character Recognition (OCR) and Handwriting Recognition engine. Your task is to accurately identify handwritten text, digits, or mathematical symbols in the provided image. Be robust against messy handwriting, rotation, and noise. Return structured JSON data.",
      },
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/png",
              data: cleanBase64,
            },
          },
          {
            text: "Analyze this handwritten content. Provide the text, confidence score, detailed analysis of the stroke/style, and alternative candidate interpretations.",
          },
        ],
      },
    });

    const endTime = performance.now();
    const processingTime = Math.round(endTime - startTime);

    if (response.text) {
      const data = JSON.parse(response.text);
      return {
        ...data,
        processingTimeMs: processingTime,
      };
    } else {
      throw new Error("No response text generated");
    }
  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    // Fallback/Error result
    return {
      recognizedText: "Error",
      confidence: 0,
      analysis: "Failed to process image. Please try again.",
      candidates: [],
      processingTimeMs: 0,
    };
  }
};